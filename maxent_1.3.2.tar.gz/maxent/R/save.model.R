save.model <-
function(model, file) {
	maxent.save.model.PWPBSBCCSCMO <- model;
	save(maxent.save.model.PWPBSBCCSCMO,file=file);
}